﻿using Microsoft.Data.SqlClient;
using ScreenSound.Modelos;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace ScreenSound.Banco
{
    internal class ArtistaDAL
    {
        // Método para obter uma lista de todos os artistas
        public IEnumerable<Artista> Listar()
        {
            var lista = new List<Artista>();

            using (var conn = new Connection().ObterConexao())
            {
                conn.Open();

                string sql = "SELECT * FROM Artistas";

                SqlCommand cmd = new SqlCommand(sql, conn);
                using SqlDataReader dataReader = cmd.ExecuteReader();

                while (dataReader.Read())
                {
                    string nomeArtista = Convert.ToString(dataReader["Nome"]);
                    string bioArtista = Convert.ToString(dataReader["Bio"]);
                    int idArtista = Convert.ToInt32(dataReader["Id"]);

                    Artista artista = new(nomeArtista, bioArtista) { Id = idArtista };

                    lista.Add(artista);
                }

                return lista;
            }
        }
        // Método para adicionar um artistas na tabela no BD.
        public void Adicionar(Artista artista)
        {
            using var connection = new Connection().ObterConexao();
            connection.Open();

            string sql = "INSERT INTO Artistas (Nome, FotoPerfil, Bio) VALUES (@nome, @perfilPadrao, @bio)";
            SqlCommand command = new SqlCommand(sql, connection);

            command.Parameters.AddWithValue("@nome", artista.Nome);
            command.Parameters.AddWithValue("@perfilPadrao", artista.FotoPerfil);
            command.Parameters.AddWithValue("@bio", artista.Bio);

            int retorno = command.ExecuteNonQuery();

            Console.WriteLine($"Linhas afetadas: {retorno}");
        }

        // Método para atualizar um artista existente
        public void Atualizar(Artista artista)
        {
            using (var conn = new Connection().ObterConexao())
            {
                conn.Open();

                string sql = @"UPDATE Artistas 
                           SET Nome = @Nome, 
                               Bio = @Bio, 
                               FotoPerfil = @FotoPerfil 
                           WHERE Id = @Id";

                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Nome", artista.Nome);
                    cmd.Parameters.AddWithValue("@Bio", artista.Bio);
                    cmd.Parameters.AddWithValue("@FotoPerfil", artista.FotoPerfil);
                    cmd.Parameters.AddWithValue("@Id", artista.Id);

                    cmd.ExecuteNonQuery();
                }
            }
        }
        // Método para excluir um artista
        public void Excluir(int id)
        {
            using (var conn = new Connection().ObterConexao())
            {
                conn.Open();

                string sql = "DELETE FROM Artistas WHERE Id = @Id";

                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", id);

                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
