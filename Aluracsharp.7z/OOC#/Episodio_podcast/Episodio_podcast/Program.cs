﻿using Episodio_podcast;

Episodio ep1 = new(4, "Técnicas de Facilitação C#", 45);
ep1.AdicionarConvidados("Maria");
ep1.AdicionarConvidados("Marcelo");
ep1.AdicionarConvidados("Valter");
//Console.WriteLine(ep1.Resumo);

Episodio ep2 = new(2, "Técnicas Iniciais C#", 45);
ep2.AdicionarConvidados("Maria");
ep2.AdicionarConvidados("Marcelo");

Episodio ep3 = new(2, "Tecnicas de aprendizado C#", 67);
ep3.AdicionarConvidados("Fernando");
ep3.AdicionarConvidados("Marcos");
ep3.AdicionarConvidados("Flavia");

Podcast podcast = new("Podcast especial C#", "Valter");
podcast.AdicionarEpisodio(ep1);
podcast.AdicionarEpisodio(ep2);
podcast.AdicionarEpisodio(ep3);
podcast.ExibirDetalhes();