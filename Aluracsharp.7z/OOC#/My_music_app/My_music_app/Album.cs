﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace My_music_app
{
    // Classe Album
    internal class Album
    {
        public string Nome { get; set; }
        public Artista Artista { get; set; }
        public List<Musica> Musicas { get; set; }

        public Album(string nome, Artista artista)
        {
            Nome = nome;
            Artista = artista;
            Musicas = new List<Musica>();
        }
    }
}
