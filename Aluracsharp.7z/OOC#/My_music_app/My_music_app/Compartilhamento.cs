﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace My_music_app
{
    // Classe Compartilhamento
    internal class Compartilhamento
    {
        // Métodos para comprar ou baixar músicas ou álbuns
        // ...
    }
}
