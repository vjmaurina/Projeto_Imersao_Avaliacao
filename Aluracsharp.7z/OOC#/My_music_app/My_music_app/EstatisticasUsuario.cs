﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace My_music_app
{
    // Classe EstatisticasUsuario
    internal class EstatisticasUsuario
    {
        // Métodos para coletar e calcular estatísticas de uso
        // ...
    }
}
