﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace My_music_app
{
    // Classe EventoMusical
    internal class EventoMusical
    {
        public string Nome { get; set; }
        public string Local { get; set; }
        public DateTime Data { get; set; }
        public List<Artista> Artistas { get; set; }

        public EventoMusical(string nome, string local, DateTime data)
        {
            Nome = nome;
            Local = local;
            Data = data;
            Artistas = new List<Artista>();
        }
    }
}
