﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace My_music_app
{
    internal class GeneroMusical
    {
        // Classe GeneroMusical
        public string Nome { get; set; }
        public string Descricao { get; set; }
        public List<Artista> Artistas { get; set; }

        public GeneroMusical(string nome, string descricao)
        {
            Nome = nome;
            Descricao = descricao;
            Artistas = new List<Artista>();
        }
    }
}
