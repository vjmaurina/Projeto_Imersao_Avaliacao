﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace My_music_app
{
    // Classe Música
    internal class Musica
    {
        public string Nome { get; set; }
        public Artista Artista { get; set; }
        public GeneroMusical Genero { get; set; }
        public double Duracao { get; set; }
        public LetraMusica Letra { get; set; }

        public Musica(string nome, Artista artista, GeneroMusical genero, double duracao, LetraMusica letra)
        {
            Nome = nome;
            Artista = artista;
            Genero = genero;
            Duracao = duracao;
            Letra = letra;
        }
    }
}
