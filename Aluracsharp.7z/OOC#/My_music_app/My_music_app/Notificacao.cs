﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace My_music_app
{
    // Classe Notificacao
    internal class Notificacao
    {
        // Métodos para gerenciar notificações
        // ...
    }
}
