﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace My_music_app
{
    // Classe Playlist
    internal class Playlist
    {
        public string Nome { get; set; }
        public List<Musica> Musicas { get; set; }

        public Playlist(string nome)
        {
            Nome = nome;
            Musicas = new List<Musica>();
        }

        public void AdicionarMusica(Musica musica)
        {
            Musicas.Add(musica);
        }

        public void RemoverMusica(Musica musica)
        {
            Musicas.Remove(musica);
        }
    }
}
