﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace My_music_app
{
    // Classe Podcast
    internal class Podcast
    {
        public string Titulo { get; set; }
        public string Descricao { get; set; }
        public double Duracao { get; set; }

        public Podcast(string titulo, string descricao, double duracao)
        {
            Titulo = titulo;
            Descricao = descricao;
            Duracao = duracao;
        }
    }
}
