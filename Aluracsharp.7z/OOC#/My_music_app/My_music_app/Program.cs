﻿// Criando objetos de exemplo
using My_music_app;

Artista artista = new Artista("Beatles", "Banda de rock britânica");
GeneroMusical genero = new GeneroMusical("Rock", "Gênero musical que se originou nos Estados Unidos");
Musica musica = new Musica("Yesterday", artista, genero, 2.5, new LetraMusica("Yesterday, all my troubles seemed so far away"));

// Criando um reprodutor musical
ReprodutorMusical reprodutor = new ReprodutorMusical();

// Reproduzindo a música
reprodutor.Reproduzir(musica);

// Ajustando o volume
reprodutor.AjustarVolume(75);

// Pausando a música
reprodutor.Pausar();