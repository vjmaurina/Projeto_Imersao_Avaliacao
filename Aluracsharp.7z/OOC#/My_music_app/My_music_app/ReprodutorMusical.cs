﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace My_music_app
{
    // Classe ReprodutorMusical
    internal class ReprodutorMusical
    {
        private Musica musicaAtual;
        private double volume;

        public ReprodutorMusical()
        {
            volume = 50; // Volume inicial
        }

        public void Reproduzir(Musica musica)
        {
            musicaAtual = musica;
            Console.WriteLine($"Reproduzindo: {musicaAtual.Nome}");
        }

        public void Pausar()
        {
            if (musicaAtual != null)
            {
                Console.WriteLine("Música pausada.");
            }
            else
            {
                Console.WriteLine("Nenhuma música em reprodução.");
            }
        }

        public void Avancar()
        {
            // Lógica para avançar para a próxima música na playlist
            // ...
        }

        public void Retroceder()
        {
            // Lógica para retroceder para a música anterior na playlist
            // ...
        }

        public void AjustarVolume(double novoVolume)
        {
            if (novoVolume >= 0 && novoVolume <= 100)
            {
                volume = novoVolume;
                Console.WriteLine($"Volume ajustado para {volume}%");
            }
            else
            {
                Console.WriteLine("Volume inválido. O volume deve estar entre 0 e 100.");
            }
        }
    }
}
