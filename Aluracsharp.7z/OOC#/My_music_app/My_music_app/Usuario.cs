﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace My_music_app
{
    // Classe Usuario
    internal class Usuario
    {
        public string Nome { get; set; }
        public string Email { get; set; }
        public string Senha { get; set; }
        public List<Playlist> Playlists { get; set; }
        public List<Musica> HistoricoReproducao { get; set; }

        public Usuario(string nome, string email, string senha)
        {
            Nome = nome;
            Email = email;
            Senha = senha;
            Playlists = new List<Playlist>();
            HistoricoReproducao = new List<Musica>();
        }
    }
}
