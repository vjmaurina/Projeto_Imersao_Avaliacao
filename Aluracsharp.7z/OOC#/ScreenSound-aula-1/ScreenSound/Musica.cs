﻿using System;
using System.Collections.Generic;

// Classe Gênero
public class Genero
{
    public string Nome { get; set; }
    /*
    public Genero(string nome)
    {
        Nome = nome;
    }
    */
}

// Classe Música
public class Musica
{
    public string Nome { get; set; }
    public string Artista { get; set; }
    public int Duracao { get; set; }
    public bool Disponivel { get; set; }
    public Genero Genero { get; set; }
    /*
    public Musica(string nome, string artista, int duracao, bool disponivel, Genero genero)
    {
        Nome = nome;
        Artista = artista;
        Duracao = duracao;
        Disponivel = disponivel;
        Genero = genero;
    }
    */
}

// Classe Álbum
public class Album
{
    private List<Musica> musicas;
    public string Nome { get; set; }
    public int DuracaoTotal { get; set; }
    //private List<Musica> Musicas { get; set; }

    public void AdicionarMusica(Musica musica)
    {
        musicas.Add(musica);
    }

    public void ExibirMusicasDoAlbum()
    {
        Console.WriteLine($"Lista de músicas do álbum {Nome}:\n");
        foreach (var musica in musicas)
        {
            Console.WriteLine($"Música: {musica.Nome}");
        }
    }


    /*
    public Album(string nome, List<Musica> musicas)
    {
        Nome = nome;
        Musicas = musicas;
        DuracaoTotal = CalcularDuracaoTotal();
    }

    private int CalcularDuracaoTotal()
    {
        int duracaoTotal = 0;
        foreach (Musica musica in Musicas)
        {
            duracaoTotal += musica.Duracao;
        }
        return duracaoTotal;
    }
    */
}