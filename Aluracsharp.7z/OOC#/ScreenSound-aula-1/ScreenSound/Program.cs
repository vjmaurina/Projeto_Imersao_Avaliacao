﻿/*
Musica musica1 = new Musica();
musica1.nome = "Roxane";
musica1.artista = "The Police";
musica1.duracao = 273;
musica1.disponivel = true;

Musica musica2 = new Musica();
musica2.nome = "Vertigo";
musica2.artista = "U2";
musica2.duracao = 367;
musica2.disponivel = false;

musica1.ExibirFichaTecnica();
musica2.ExibirFichaTecnica();
*/

/*
List<int> numeros = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

List<int> numerosPares = numeros.FindAll(BuscarNumerosQueSaoPares);

bool BuscarNumerosQueSaoPares(int numero)
{
    return numero % 2 == 0;
}
Console.WriteLine("Temos uma lista de números inteiros <1, 2, 3, 4, 5, 6, 7, 8, 9, 10> e deseje filtrar apenas os números pares.");
foreach (int numero in numerosPares)
{
    Console.WriteLine(numero);
}
*/
// Usando Lambda para mostrar os números PARES.
/*List<int> numeros = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

List<int> numerosPares = numeros.FindAll(numero => numero % 2 == 0);
numerosPares.ForEach(numero => Console.WriteLine(numero));
*/

/*
// Criando um gênero musical
Genero rock = new Genero("Rock");

// Criando músicas
Musica musica1 = new Musica("Bohemian Rhapsody", "Queen", 360, true, rock);
Musica musica2 = new Musica("Stairway to Heaven", "Led Zeppelin", 480, true, rock);
Musica musica3 = new Musica("Hotel California", "Eagles", 330, true, rock);

// Criando um álbum
List<Musica> musicasAlbum = new List<Musica>() { musica1, musica2, musica3 };
Album album = new Album("Greatest Hits", musicasAlbum);

// Imprimindo informações
Console.WriteLine($"Álbum: {album.Nome}");
Console.WriteLine($"Duração Total do Álbum: {album.DuracaoTotal} segundos");

Console.WriteLine("\nLista de Músicas:");
foreach (Musica musica in album.Musicas)
{
    Console.WriteLine($"Nome: {musica.Nome}, Artista: {musica.Artista}, Duração: {musica.Duracao} segundos, Disponível: {musica.Disponivel}, Gênero: {musica.Genero.Nome}");
}

Console.ReadKey();
*/

Album albumDoQueen = new Album();
albumDoQueen.Nome = "A night at the opera";

Musica musica1 = new Musica();
musica1.Nome = "Love of my life";

Musica musica2 = new Musica();
musica2.Nome = "Bohemian Rhapsody";

albumDoQueen.AdicionarMusica(musica1);
albumDoQueen.AdicionarMusica(musica2);

albumDoQueen.ExibirMusicasDoAlbum();

