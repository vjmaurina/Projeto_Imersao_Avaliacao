﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScreenSound
{
    class Album
    {
        private List<Musica> musicas = new List<Musica>();

        public string Nome { get; set; }
        public int DuracaoTotal => musicas.Sum(m => m.Duracao);
        public Genero Genero { get; set; }

        public void AdicionarMusica(Musica musica)
        {
            musicas.Add(musica);
        }

        public void ExibirMusicasDoAlbum()
        {
            Console.WriteLine($"Lista de músicas do álbum: {Nome}:\n");
            Console.WriteLine($"Gênero: {Genero.Nome} ");
            foreach (var musica in musicas)
            {
                Console.WriteLine($"Nome do Musica: {musica.Nome}");
            }
            Console.WriteLine($"\nPara ouvir este álbum inteiro você precisa de {DuracaoTotal}");
        }
    }
}

