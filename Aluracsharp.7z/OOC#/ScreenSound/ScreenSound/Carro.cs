﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ScreenSound
{
    // 1 - Desenvolver uma classe que modele um carro, e que contenha os métodos acelerar, frear e buzinar
    // 2 - Reescrever os atributos da classe Carro, de modo que eles sejam properties, e adicionar uma nova propertie DescricaoDetalhada, que mostra o fabricante, modelo e ano do carro.
    // 3 - Reescrever a propriedade Ano da classe carro, para que ela apenas aceite valores entre 1960 e 2023.
    internal class Carro
    {
        public string Fabricante { get; set; }
        public string Modelo { get; set; }
        //public int Ano { get; set; }
        public int Ano
        {
            get => Ano;
            set
            {
                if (value < 1960 || value > 2023)
                {
                    Console.WriteLine("Valor inválido, insira um ano entre 1960 e 2023");
                }
                else
                {
                    Ano = value;
                }
            }
        }

        public int QuantidadePortas { get; set; }
        public int velocidade = 0;
        public string DescricaoDetalhada => $"Modelo do carro: {this.Fabricante} {this.Modelo} {this.Ano}";
        
        public void exibirInformacoes()
        {
            Console.WriteLine($"INFORMAÇÕES DO CARRO: {this.Fabricante} {this.Modelo}, {this.QuantidadePortas} portas, {this.Ano}");
        }

        public void acelerar()
        {
            Console.WriteLine("Acelerando...");
            if (velocidade < 100)
            {
                velocidade = velocidade + 5;
            }
        }

        public void frear()
        {
            Console.WriteLine("Freando...");
            if (velocidade > 0)
            {
                velocidade = velocidade - 5;
            }
        }

        public void buzinar()
        {
            Console.WriteLine("Bi Bi");
        }

    }
}
