﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScreenSound
{
    //1- Criar uma classe que representa uma conta bancária, com um número indicador, titular, saldo e senha.
    //2- Reescrever a classe Conta, utilizando properties.
    internal class Conta
    {
        private object senha;

        public int Titular { get; set; }
        public int Id { get; set; }
        public float Saldo { get; set; }
        public int Senha { get; set; }

        //Desenvolver um método da classe Conta que exibe suas informações.
        public void exibirInformacoes()
        {
            Console.WriteLine("INFORMAÇÕES DA CONTA:");
            Console.WriteLine($"Titular: {this.Titular}");
            Console.WriteLine($"Saldo atual: {this.Saldo}");
        }
        public void ExibirSenha()
        {
            Console.WriteLine($"Senha: {Senha}");
        }

    }
}