﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScreenSound
{
    /*
     * Desenvolver a classe Produto, com os atributos nome, marca, preco e estoque. 
     * Além disso, garantir que o preço e o estoque do produto sejam valores positivos 
     * e criar uma propriedade que mostra detalhadamente as informações do produto, para que seja usado pela equipe de vendas.
     */
    internal class Produto
    {
        private double preco;
        private int estoque;
        public required string Nome { get; set; }
        public string Marca { get; set; }
        public double Preco
        {
            get => preco;
            set
            {
                if (value > 0)
                    preco = value;
                else
                    preco = 10;
            }
        }
        public int Estoque
        {
            get => estoque;
            set
            {
                if (value > 0)
                    estoque = value;
                else
                    estoque = 0;

            }
        }

        public string DescricaoProduto => $"{this.Nome} {this.Marca} - {this.Preco}";

        public int Somar(int a, int b)
        {
            int resultado = a + b;
            return resultado;
        }

        //public int Somar(int a, int b) => a + b;
        public int SomarLambda(int v1, int v2) => v1 + v2;

    }
}
