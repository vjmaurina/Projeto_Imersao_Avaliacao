﻿using ScreenSound;

// Criar um objeto do tipo Conta, adicionar dados e mostrar as informações titular e saldo no console, utilizando interpolação de strings.
/*
Conta conta = new Conta();

conta.Titular = "Valter Maurina";
conta.id = 1;
conta.Saldo = 200;
conta.senha = 1234;

conta.exibirInformacoes();
conta.ExibirSenha();

Carro carro = new Carro();
carro.fabricante = "NISSAN";
carro.modelo = "KICKS";
carro.ano = 2023;
carro.quantidadePortas = 5;
carro.velocidade = 100;

//métodos da clase carro...
carro.exibirInformacoes();
carro.acelerar();
carro.frear();
carro.buzinar();
*/
/*
Produto produto = new Produto();
produto.Nome = "Feijão";
produto.Marca = "Carioquinha";
produto.Preco = 0;

Console.WriteLine(produto.DescricaoProduto); 
*/

// Criando um objeto Titular Conta1
Titular titular = new Titular
{
    Nome = "João da Silva",
    Cpf = "123.456.789-00",
    Endereco = "Rua dos Bobos, nº 0"
};

// Criando um objeto Conta1
Conta1 conta = new Conta1
{
    Titular = titular,
    Agencia = 1234,
    NumeroDaConta = 5678,
    Saldo = 1000.00,
    Limite = 500.00
};

// Imprimindo as informações da conta
Console.WriteLine(conta.Informacoes);
