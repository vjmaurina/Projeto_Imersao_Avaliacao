﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace my_catalogo_de_jogos
{
    internal class CatalogoDeJogos
    {
        private List<Jogo> jogos;
        public CatalogoDeJogos()
        {
            jogos = new List<Jogo>();
        }
        
        // Método para adicionar um jogo ao catálogo
        public void AdicionarJogo(Jogo jogo)
        {
            jogos.Add(jogo);
        }

        // Método para remover um jogo do catálogo
        public void RemoverJogo(string nomeJogo)
        {
            jogos.RemoveAll(jogo => jogo.Nome == nomeJogo);
        }

        // Método para buscar um jogo pelo nome
        public Jogo BuscarJogo(string nomeJogo)
        {
            return jogos.Find(jogo => jogo.Nome == nomeJogo);
        }

        // Método para listar todos os jogos do catálogo
        public void ListarJogos()
        {
            if (jogos.Count == 0)
            {
                Console.WriteLine("O catálogo está vazio.");
                return;
            }

            Console.WriteLine("Lista de jogos:");
            foreach (Jogo jogo in jogos)
            {
                Console.WriteLine($"Nome: {jogo.Nome}, Gênero: {jogo.Genero}, Preço: R${jogo.Preco:F2}");
            }
        }

    }
}
