﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace my_catalogo_de_jogos
{
    internal class Jogo
    {
        public String Nome { get; set; }
        public string Genero { get; set; }
        public double Preco { get; set; }

        public Jogo(string nome, string genero, double preco)
        {
            Nome = nome;
            Genero = genero;
            Preco = preco;
        }
    }
}
