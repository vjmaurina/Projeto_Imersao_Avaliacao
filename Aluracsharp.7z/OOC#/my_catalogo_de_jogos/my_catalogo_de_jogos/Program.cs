﻿// Criando um catálogo de jogos
using my_catalogo_de_jogos;

CatalogoDeJogos catalogo = new CatalogoDeJogos();

// Adicionando jogos ao catálogo
catalogo.AdicionarJogo(new Jogo("The Legend of Zelda: Breath of the Wild", "Aventura", 200.00));
catalogo.AdicionarJogo(new Jogo("Super Mario Odyssey", "Plataforma", 150.00));
catalogo.AdicionarJogo(new Jogo("Mario Kart 8 Deluxe", "Corrida", 120.00));
catalogo.AdicionarJogo(new Jogo("joao secada", "facada", 1000.00));

// Listando os jogos do catálogo
catalogo.ListarJogos();

// Buscando um jogo pelo nome
Jogo jogoEncontrado = catalogo.BuscarJogo("joao secada");
if (jogoEncontrado != null)
{
    Console.WriteLine($"\nJogo encontrado: {jogoEncontrado.Nome}");
}
else
{
    Console.WriteLine("\nJogo não encontrado.");
}

// Removendo um jogo do catálogo
catalogo.RemoverJogo("joao secada");

// Buscando new jogo pelo nome
Jogo newjogoEncontrado = catalogo.BuscarJogo("joao secada");
if (newjogoEncontrado != null)
{
    Console.WriteLine($"\nJogo encontrado: {newjogoEncontrado.Nome}");
}
else
{
    Console.WriteLine($"\nJogo 'joao secada' não encontrado.");
}

// Listando os jogos novamente
Console.WriteLine("\nLista de jogos após a remoção:");
catalogo.ListarJogos();

Console.ReadKey();